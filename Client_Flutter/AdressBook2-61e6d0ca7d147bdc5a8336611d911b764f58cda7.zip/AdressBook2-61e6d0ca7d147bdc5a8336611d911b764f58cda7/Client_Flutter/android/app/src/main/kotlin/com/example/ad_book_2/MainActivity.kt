package com.example.ad_book_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
